[+] Install package [+]
[-] npm install puppeteer

[+] What to edit [+] 
[-] Go to line 15 and replave that with your chrome directory 
[-] Go to line 20 and put the profile link you would like to boost stats for :)

[+] Disclaimer [+] 
I made this cause why not.
I am not responsible for anything one will do with this program.
