.. _install-alma-linux-8:

====================================
Installing Red on Alma Linux 8.4-8.x
====================================

.. include:: _includes/install-guide-rhel8-derivatives.rst
