<h2 align="center">OnlyfansSearcher</h2>
<br>
<br>
<p align="center">
<img src="https://cdn.discordapp.com/attachments/848605280468336664/867053046562684928/ttt.gif" width="300" height="300">
</p>

# ⭐️ Features
 - Scrape onlyfans leaks
 - Easy to use
 - Really fast tool (under 10 seconds for a search)
 - Automatically save your scraped links in a txt file

# ⭐️ How to install
 - Step 1 : Open the .sln file
 - Step 2 : Double click on OnlyfansSearcher and  double click on Program.cs
 - Step 3 : As you can see "Console = Colorful.Console;" and others is not working. Now right click on reference -> add a new reference
 - Step 4 : Go to "OnlyfansSearcher-main\OnlyfansSearcher\@IMPORT ALL DLL" and import all dll.
 - Step 5 : Click "ok", and enjoy !
<br><br><br><br>
<p align="center">
<b><samp> Follow me :</samp></b><br>
  <a href="https://cracked.to/Zekh">Cracked.to</a> |
  <a href="https://www.youtube.com/channel/UCl-6uAXenlJFFDUa_Fu07SQ">Youtube</a>
</p>
