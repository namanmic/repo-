﻿using System;
using System.Drawing;
using Console = Colorful.Console;


namespace OnlyfansSearcher
{
    class Onlyfansheader
    {
        public static void Header1()
        {
            var Zekh = new string[]
{
@"
                        ___       _        __                  __                     _               
                       /___\_ __ | |_   _ / _| __ _ _ __  ___ / _\ ___  __ _ _ __ ___| |__   ___ _ __ 
                      //  // '_ \| | | | | |_ / _` | '_ \/ __|\ \ / _ \/ _` | '__/ __| '_ \ / _ \ '__|
                     / \_//| | | | | |_| |  _| (_| | | | \__ \_\ \  __/ (_| | | | (__| | | |  __/ |   
                     \___/ |_| |_|_|\__, |_|  \__,_|_| |_|___/\__/\___|\__,_|_|  \___|_| |_|\___|_|   
                                    |___/   
					            cracked.to/Zekh
",
};
            foreach (string line in Zekh) { Console.WriteLine(line, Color.DeepPink); }
        }
    }
}
