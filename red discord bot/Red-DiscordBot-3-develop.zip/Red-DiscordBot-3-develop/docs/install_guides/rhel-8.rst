.. _install-rhel-8:

=========================================================
Installing Red on Red Hat Enterprise Linux (RHEL) 8.4-8.x
=========================================================

.. include:: _includes/install-guide-rhel8-derivatives.rst
