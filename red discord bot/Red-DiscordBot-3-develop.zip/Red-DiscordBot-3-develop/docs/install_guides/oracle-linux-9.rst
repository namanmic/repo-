.. _install-oracle-linux-9:

================================
Installing Red on Oracle Linux 9
================================

.. include:: _includes/install-guide-rhel9-derivatives.rst
